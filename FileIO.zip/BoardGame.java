package Week7;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class BoardGame implements Serializable {
    String name;
    int numDice;
    int numCards;

    public BoardGame() {

    }

    public BoardGame(String name, int numDice, int numCards) {
        this.name = name;
        this.numDice = numDice;
        this.numCards = numCards;
    }

    public String getName() {
        return name;
    }

    public int getNumDice() {
        return numDice;
    }

    public int getNumCards() {
        return numCards;
    }

    @Override
    public String toString() {
        return name + ": cards: " + numCards + " dice: " + numDice;
    }
    public void save() {
        try (ObjectOutputStream out =
                     new ObjectOutputStream(new FileOutputStream("game.bin"))) {
            out.writeObject(this);
        } catch (FileNotFoundException e) {

        } catch (IOException ex) {

        }
    }
}
