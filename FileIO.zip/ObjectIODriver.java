package Week7;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ObjectIODriver {
    public static void main(String[] args) {
        BoardGame game = new BoardGame("Monopoly", 2, 60);
        System.out.println(game);
        game.save();
        game = new BoardGame();

        try(ObjectInputStream in =
                    new ObjectInputStream(new FileInputStream("game.bin"))) {
            game = (BoardGame)in.readObject();
        } catch(IOException e) {

        } catch(ClassNotFoundException ex) {

        }

        System.out.println(game);

        try(DataOutputStream dout =
                    new DataOutputStream(new FileOutputStream("game.dat"))) {
            dout.writeInt(game.getNumDice());
            dout.writeInt(game.getNumCards());
            dout.writeChars(game.getName());
        } catch(FileNotFoundException e) {

        } catch (IOException ex) {

        }
        String name = "";
        float dice = 0F;
        try(DataInputStream din =
                    new DataInputStream(new FileInputStream("game.dat"))) {
            dice = din.readFloat();
            int cards = din.readInt();
            while(true) {
                name += din.readChar();
            }
        } catch(FileNotFoundException e) {

        } catch (IOException ex) {
            System.out.println(ex.getClass());
        }

        System.out.println(dice);
    }
}
