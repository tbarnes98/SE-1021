package Week2.InClassExercise1;


public class Person {

    private String name;

}