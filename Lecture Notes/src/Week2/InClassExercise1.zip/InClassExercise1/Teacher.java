package Week2.InClassExercise1;

public class Teacher extends Person {

    public double salary;

    public double calculateTaxes() {
        return 0.0;
    }
}
