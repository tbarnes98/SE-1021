package Week2.InClassExercise1;

import java.util.ArrayList;

public class Section {

    private ArrayList<Person> students = new ArrayList<>();
    private String classroom;

    public int numStudents() {
        return 0;
    }

    public void display() {

    }
}
