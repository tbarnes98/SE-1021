package Week2.InClassExercise1;

import java.util.ArrayList;

public class Course {
    private ArrayList<Section> sections = new ArrayList<>();
    private String prefix;
    private int courseNumber;

    public void display() {

    }

    @Override
    public boolean equals(Object o) {
        return false;
    }
}
