package Week2.InClassExercise1;

import java.util.ArrayList;

public class Student {

    private ArrayList<Integer> quizzes = new ArrayList<>();

    public double quizAverage() {
        return 0.0;
    }

    public void display(){

    }
}
