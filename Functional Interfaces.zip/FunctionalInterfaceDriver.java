package Week8;

public class FunctionalInterfaceDriver {
    public static void main(String[] args) {
        int e = 5;
        calculate(f -> (int)Math.pow(f, 3), e);
        calculate(f -> (f + 7) / 2, e);
        doStuff((s, d) -> {
            String temp = s.substring(0, s.length() / 2);
            temp += d;
            temp += s.substring(s.length()/2, s.length());
            System.out.println(temp);
        }, "goodbye", 13.6);
    }

    public static void calculate(MathStuff m, int x) {
        System.out.println(m.mathymath(x));
    }

    public static void doStuff(DifficultInterface d, String s, double db) {
        d.hardStuff(s, db);
    }
}
