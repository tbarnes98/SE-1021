package Week8;

@FunctionalInterface
public interface MathStuff {
    int mathymath(int x);
}
