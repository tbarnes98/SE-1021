package Week8;

@FunctionalInterface
public interface DifficultInterface {
    void hardStuff(String s, double d);
}
